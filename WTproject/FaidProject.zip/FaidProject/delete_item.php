
<?php

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/admin_check.php";

function sendResponse($success, $message, $status = 200) {
    http_response_code($status);

    echo json_encode([
        "success" => $success,
        "message" => $message
    ], JSON_UNESCAPED_UNICODE);

    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    sendResponse(false, "Invalid request method.", 405);
}

$type = $_POST["type"] ?? "";
$id = filter_var($_POST["id"] ?? null, FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    sendResponse(false, "Invalid record ID.", 400);
}

$tables = [
    "companies" => [
        "table" => "companies",
        "column" => "company_id",
        "message" => "Company and related records deleted successfully."
    ],

    "materials" => [
        "table" => "materials",
        "column" => "material_id",
        "message" => "Material and related order details deleted successfully."
    ],

    "orders" => [
        "table" => "orders",
        "column" => "order_id",
        "message" => "Order and its details deleted successfully."
    ]
];

if (!isset($tables[$type])) {
    sendResponse(false, "Invalid record type.", 400);
}

$table = $tables[$type]["table"];
$column = $tables[$type]["column"];

try {

    $conn->begin_transaction();

    $sql = "DELETE FROM `$table` WHERE `$column` = ?";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        throw new Exception("Failed to prepare delete statement.");
    }

    $stmt->bind_param("i", $id);

    if (!$stmt->execute()) {
        throw new Exception("Delete operation failed.");
    }

    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->rollback();

        sendResponse(false, "Record not found.", 404);
    }

    $stmt->close();

    $conn->commit();

    sendResponse(true, $tables[$type]["message"]);

} catch (Throwable $error) {

    $conn->rollback();

    error_log("Delete Error: " . $error->getMessage());

    sendResponse(
        false,
        "Delete failed. Please check database relationships.",
        500
    );
}

?>
